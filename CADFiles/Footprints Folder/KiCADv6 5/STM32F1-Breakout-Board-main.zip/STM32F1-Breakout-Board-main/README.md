# STM32F1-Breakout-Board
 USB-powered STM32F1-based breakout board. Video: https://www.youtube.com/watch?v=wLwKgMBWhpY

 You can order this board (incl. SMT assembly) at https://www.jlcpcb.com. Gerber and assembly files are in the relevant repo folders.
